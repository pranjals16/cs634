// 0 : MS to BSold
// 1 : BSold to BSCold
public class Data
{
	int signal[6];
	String MSISDN;
	int type;
	String BS;
	public Data(int[] a, String b,int c,String d)
	{
		this.MSISDN=b;
		this.type=c;
		this.BS=d;
		for(int i=0;i<6;i++)
			this.signal[i]=a[i];
	}
}
