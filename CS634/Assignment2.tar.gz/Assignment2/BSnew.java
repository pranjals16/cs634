import java.io.*;
import java.net.*;
import java.util.*;

public class BSnew extends Thread
{
	static String BSC_ID="2";
	static int port_BSC=6793;
	static String BS_ID="2";
	static int port_MS=6788;
	static int port_MSC=6792;
	static void flush(Message m)
	{
		try {
		Socket fl=new Socket(InetAddress.getLocalHost().getHostName(), port_MSC);
		Message newm=new Message(12,m.MSISDN,m.oldBSC,m.oldBS,"","",0);
		ObjectOutputStream out=new ObjectOutputStream(fl.getOutputStream());
		out.writeObject(newm);
		return;
		}
		catch(Exception e){ e.printStackTrace();}
	}
	static ArrayList<String> mobList=new ArrayList<String>();	
	public static void main(String arg[]) throws Exception
	{
		Thread t2=new Thread(new Runnable() {
		public void run()
		{
			try{
				ServerSocket newTCH=new ServerSocket(6795);
				while(true)
				{
					Socket s=newTCH.accept();
					System.out.println("accepted");
					ObjectOutputStream out=new ObjectOutputStream(s.getOutputStream());
					ObjectInputStream in=new ObjectInputStream(s.getInputStream());
					Message m= (Message)in.readObject();
					if(mobList.contains(m.MSISDN) && m.type==10)
					{
						System.out.println("Link request received");
						Message newm=new Message(11,m.MSISDN,"","",m.newBSC,BS_ID,0);
						out.writeObject(newm);
					}
					else s.close();
				}
			}
			catch (Exception e) {System.out.println("Disconnected");}
		}
		});t2.start();
		Thread t1=new Thread(new Runnable() {
		public void run()
		{
			try{
				//socket for left to contact
		  		ServerSocket new_bs=new ServerSocket(6794);
				System.out.println("Socket created for left to contact");
				while(true)
				{
					Socket s=new_bs.accept();
					int sig[]=new int[6];
					ObjectInputStream in=new ObjectInputStream(s.getInputStream());
					Message m =(Message) in.readObject();
					s.close();
					//change m to newm
					// 4 : from BSCnew to BSnew (4,MSISDN, oldBS no,oldBSC, newBSC, newBS)
					// 5 : from BSnew to BSCnew
					if(m.type==4)
					{
						Message newm=new Message(5,m.MSISDN,m.oldBS,m.oldBSC,m.newBSC,m.newBS,6795);
						Socket sck=new Socket(InetAddress.getLocalHost().getHostName(), port_BSC);
						ObjectOutputStream out=new ObjectOutputStream(sck.getOutputStream());
						out.writeObject(newm);
						System.out.println("Sending ack to new BSC");
						mobList.add(m.MSISDN);
						sck.close();
						//check if request for deletion
					}			   
			    }
				}
		    catch(Exception e) { e.printStackTrace();}
		}
		});t1.start();
	}
}
