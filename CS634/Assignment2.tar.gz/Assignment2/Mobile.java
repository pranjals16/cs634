import java.io.*;
import java.util.*;
import java.net.*;
class ScheduledTask extends TimerTask {
 	String MSISDN;
	String BS;
	int BS_port;
	public ScheduledTask(String a,String b,int c)
	{
		this.MSISDN=a;
		this.BS=b;
		this.BS_port=c;
	}
	public void run() {
		Random rand=new Random();
		int sig[]=new int[2];
		for(int i=0;i<2;i++)
			sig[i]=rand.nextInt(10)+1;
		try{
		
		Socket clientSocket=new Socket(InetAddress.getLocalHost().getHostName(),BS_port);	
		ObjectOutputStream toBS=new ObjectOutputStream(clientSocket.getOutputStream());System.out.println("Gathering signals");
		Message m=new Message(0,MSISDN,BS,"","","",0,sig);
		System.out.println("Sending request. Signal levels="+sig[0]+" and "+sig[1]);
		toBS.writeObject(m);
		clientSocket.close();
		}
		catch(Exception e){e.printStackTrace();}
	}
}

public class Mobile extends Thread
{
	static int port_BS=6790;
	static String BS_ID="BS1";
	static void connect(int port,String MSISDN)
	{
		try {
		System.out.println("Connecting to "+port);
		Socket s=new Socket(InetAddress.getLocalHost().getHostName(),port);
		ObjectOutputStream toBS=new ObjectOutputStream(s.getOutputStream());
		ObjectInputStream fromBS=new ObjectInputStream(s.getInputStream());
		Message m=new Message(10,MSISDN,"","","","",0);
		toBS.writeObject(m);
		Message newm=(Message)fromBS.readObject();
		if(newm.type==11)
		{
			System.out.println("Handoff complete. New BS="+port);
		}
		}
		catch (Exception e) {e.printStackTrace();}
	}
	public static void main(String arg[]) throws Exception
	{
		String sentence;
		String serverSentence;
		int SACCH=6790;
		BufferedReader fromUser=new BufferedReader(new InputStreamReader(System.in));
		/*System.out.println("Enter the SIM details");
		System.out.print("IMSI:");
		String IMSI=fromUser.readLine();*/
		System.out.print("MSISDN:");
		String MSISDN=fromUser.readLine();
		/*SIM sim= new SIM(IMSI,MSISDN,"","","","","","","","");
		System.out.println("Enter the mobile handset details");
		System.out.print("IMEI:");
		String IMEI=fromUser.readLine();
		MS ms=new MS(IMEI,sim);
		Random rand=new Random();
		int num;*/
		ScheduledTask st=new ScheduledTask(MSISDN,BS_ID,SACCH);
		final Timer t=new Timer(true);
		t.schedule(st,0,5000);
		Thread t1=new Thread(new Runnable() {
		public void run ()
		{
			try{
			ServerSocket s=new ServerSocket(6788);
			while(true)
			{			
				Socket sck=s.accept();//System.out.println("Accepted");
				ObjectOutputStream o=new ObjectOutputStream(sck.getOutputStream());
				ObjectInputStream i=new ObjectInputStream(sck.getInputStream());
				Message n=(Message)i.readObject();
				sck.close();
				if(n.newChannel!=0 && n.type==9)
				{
					System.out.println("Handoff ack received");t.cancel();
					port_BS=n.newChannel;
					connect(port_BS,n.MSISDN);
				}
				
			}
			}
			catch(Exception e){e.printStackTrace();}
		}
		});
		t1.start();
		/*while(true)
		{
			Socket clientSocket=new Socket(InetAddress.getLocalHost().getHostName(),port_BS);
			System.out.println("Currently in MSC "+(num+1));
			ObjectOutputStream outServer=new ObjectOutputStream(clientSocket.getOutputStream());
			ObjectInputStream fromServer=new ObjectInputStream(clientSocket.getInputStream());
			outServer.writeObject(ms);
			int i=0;
			System.out.println("waiting for registration");
			ms=(MS)fromServer.readObject();
			if(ms.sim.Ki.equals("Invalid")) {System.out.println("INVALID NUMBER");return;}
			System.out.println("registered");
			while((i++)<5){
				System.out.println("Enter sentence");
				sentence=fromUser.readLine();
				outServer.writeObject(sentence);
				serverSentence=(String)fromServer.readObject();
				System.out.println(serverSentence);
			}
	      		clientSocket.close();
		}*/
	}
}	
