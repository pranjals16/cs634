import java.io.*;
import java.net.*;
import java.util.*;

public class MSC extends Thread
{
	static String BSC[]={"1","2"};
	static int port_BSC[]={6791,6793};
	static void flush(Message m)
	{
	}
	public static void main(String arg[]) throws Exception
	{
		Thread t1=new Thread(new Runnable() {
		public void run()
		{
			try{
				//socket for left to contact
		  		ServerSocket msc=new ServerSocket(6792);
				System.out.println("Socket created for left to contact");
				while(true)
				{
					Socket s=msc.accept();
					int sig[]=new int[6];
					ObjectInputStream in=new ObjectInputStream(s.getInputStream());
					Message m =(Message) in.readObject();
					s.close();
					if(m.type==2)  //  from BSCold to MSC (2,MSISDN, oldBS, oldBSC, null, newBS)
					{
						String newBS=m.newBS;
						System.out.println("New BS="+newBS);
						String newBSC=BSC[Integer.parseInt(newBS)-1];		//finding the new BSC number				
						// from MSC to BSCnew (3,MSISDN, oldBS, oldBSC, newBSC, newBS)
						Message newm=new Message(3,m.MSISDN,m.oldBS,m.oldBSC,newBSC,newBS,0);
						//change m to newm
						Socket sck=new Socket(InetAddress.getLocalHost().getHostName(), port_BSC[Integer.parseInt(newBSC)-1]);
						ObjectOutputStream out=new ObjectOutputStream(sck.getOutputStream());
						out.writeObject(newm);
						System.out.println("Sending request to new BSC");
						sck.close();
						//check if request for deletion
					}
					// 6 : from BSCnew to MSC
					// 7 : from MSC to BSCold
					if(m.type==6)
					{
						Message newm=new Message(7,m.MSISDN, m.oldBS,m.oldBSC,m.newBSC,m.newBS,m.newChannel);
						Socket sck=new Socket(InetAddress.getLocalHost().getHostName(), port_BSC[Integer.parseInt(m.oldBSC)-1]);
						ObjectOutputStream out=new ObjectOutputStream(sck.getOutputStream());
						out.writeObject(newm);
						System.out.println("Sending ack to old BSC");
						sck.close();
					}
					if(m.type==12)
					{
						flush(m);
					}
			    }
				}
		    catch(Exception e) { e.printStackTrace();}
		}
		});t1.start();
	}
}
