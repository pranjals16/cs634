import java.io.*;
import java.net.*;
import java.util.*;

public class BSCold extends Thread
{
	static String BSC_ID="1";
	static String BS_ID="BS1";
	static int port_MSC=6792;
	static int port_BS=6790;
	public static void main(String arg[]) throws Exception
	{
		Thread t1=new Thread(new Runnable() {
		public void run()
		{
			try{
				//socket for left to contact
		  		ServerSocket old_bsc=new ServerSocket(6791);
				System.out.println("Socket created for left to contact");
				while(true)
				{
					Socket s=old_bsc.accept();
					int sig[]=new int[6];
					ObjectInputStream in=new ObjectInputStream(s.getInputStream());
					Message m =(Message) in.readObject();
					s.close();
					//: from BS to BSC old(1,MSISDN, oldBS, oldBSC, null, newBS)
					//: from BSCold to MSC (2,MSISDN, oldBS, oldBSC, null, newBS)
					if(m.type==1)
					{
						for(int i=0;i<2;i++)
							sig[i]=m.signal[i];
						int min=sig[0];int min_index=0;
						for(int i=1;i<2;i++)
							if(min>sig[i]) {
								min=sig[i];
								min_index=i;
							}
						if(min_index==1 ||  min >5) {s.close(); continue;}
						
						//System.out.println("NEW BS="+Integer.toString(min_index+1));
						Message newm=new Message(2,m.MSISDN,m.oldBS,m.oldBSC,"","2",0);
						System.out.println("Sending message to MSC"+newm.newBS+"sig");
						Socket sck=new Socket(InetAddress.getLocalHost().getHostName(), port_MSC);
						ObjectOutputStream out=new ObjectOutputStream(sck.getOutputStream());
						out.writeObject(newm);
						sck.close();
					}
					// 7 : from MSC to BSCold
					// 8 : from BSCold to BSold		
					if(m.type==7)
					{
						Message newm=new Message(8,m.MSISDN,m.oldBS,m.oldBSC,m.newBSC,m.newBS,m.newChannel);
						//change m to newm
						Socket sck=new Socket(InetAddress.getLocalHost().getHostName(), port_BS);
						ObjectOutputStream out=new ObjectOutputStream(sck.getOutputStream());
						out.writeObject(newm);
						System.out.println("Sending ack to old BS");
						sck.close();
					}
			    }
				}
		    catch(Exception e) { e.printStackTrace();}
		}
		});t1.start();
	}
}
