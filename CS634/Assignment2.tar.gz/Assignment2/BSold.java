import java.io.*;
import java.net.*;
import java.util.*;

public class BSold extends Thread
{
	static String BSC_ID="1";
	static int port_BSC=6791;
	static String BS_ID="1";
	static int port_MS=6788;
	public static void main(String arg[]) throws Exception
	{
		/*Thread t2=new Thread(new Runnable() {
		public void run()
		{
			try{
				ServerSocket oldTCH=new ServerSocket(6789);
				while(true)
				{
					Socket s=oldTCH.accept();
					ObjectOutputStream out=new ObjectOutputStream(s.getOutputStream());
					ObjectInputStream in=new ObjectInputStream(s.getInputStream());
					Message m= (Message)in.readObject();
					if(Integer.parseInt(m.oldBS)==1)
					{
						System.out.println(m.MSISDN+" is connected to BS1");
					}
					else s.close();
				}
			}
			catch (Exception e) {System.out.println("Disconnected");}
		}
		});
		t2.start();*/
		Thread t1=new Thread(new Runnable() {
		public void run()
		{
			try{
				//socket for left to contact
		  		ServerSocket old_bs=new ServerSocket(6790);
				System.out.println("Socket created for left to contact");
				while(true)
				{
					Socket s=old_bs.accept();
					int sig[]=new int[2];
					ObjectInputStream in=new ObjectInputStream(s.getInputStream());
					Message m =(Message) in.readObject();
					s.close();
					if(m.type==0)
					{
						Message newm=new Message(1,m.MSISDN,BS_ID,BSC_ID,"","",0,m.signal);
						//change m to newm
						System.out.println("sending signals to BSC");
						Socket sck=new Socket(InetAddress.getLocalHost().getHostName(),port_BSC);
						ObjectOutputStream out=new ObjectOutputStream(sck.getOutputStream());
						out.writeObject(newm);
						sck.close();
						//check if request for deletion
					}
					if(m.type==8)
					{
						Message newm=new Message(9,m.MSISDN,m.oldBS,m.oldBS,m.newBSC,m.newBS,m.newChannel);
						Socket sck=new Socket(InetAddress.getLocalHost().getHostName(), port_MS);
						ObjectOutputStream out=new ObjectOutputStream(sck.getOutputStream());
						out.writeObject(newm);
						System.out.println("Sending ack to MS");
						sck.close();
					}
							   
			    }
				}
		    catch(Exception e) { e.printStackTrace();}
		}
		});
		t1.start();
	}
}
