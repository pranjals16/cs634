import java.io.*;
import java.net.*;
import java.util.*;

public class Mobile
{
	public static void main(String arg[]) throws Exception
	{
		String sentence;
		String serverSentence;
		int port[]={6789,6791,6793};
		BufferedReader fromUser=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter the SIM details");
		System.out.print("IMSI:");
		String IMSI=fromUser.readLine();
		System.out.print("MSISSDN:");
		String MSISDN=fromUser.readLine();
		SIM sim= new SIM(IMSI,MSISDN,"","","","","","","","");
		System.out.println("Enter the mobile handset details");
		System.out.print("IMEI:");
		String IMEI=fromUser.readLine();
		MS ms=new MS(IMEI,sim);
		Random rand=new Random();
		int num;
		while(true)
		{
			num=rand.nextInt(3);
			Socket clientSocket=new Socket(InetAddress.getLocalHost().getHostName(),port[num]);
			System.out.println("Currently in MSC "+(num+1));
			ObjectOutputStream outServer=new ObjectOutputStream(clientSocket.getOutputStream());
			ObjectInputStream fromServer=new ObjectInputStream(clientSocket.getInputStream());
			outServer.writeObject(ms);
			int i=0;
			System.out.println("waiting for registration");
			ms=(MS)fromServer.readObject();
			if(ms.sim.Ki.equals("Invalid")) {System.out.println("INVALID NUMBER");return;}
			System.out.println("registered");
			while((i++)<5){
				System.out.println("Enter sentence");
				sentence=fromUser.readLine();
				outServer.writeObject(sentence);
				serverSentence=(String)fromServer.readObject();
				System.out.println(serverSentence);
			}
	      		clientSocket.close();
		}
	}
}	
