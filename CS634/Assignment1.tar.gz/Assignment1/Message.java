import java.io.*;

//0 hlr responds to vlr about ms affirmative
//-1 hlr responds to vlr ablout ms negative
//1 vlr tells hlr about ms in foreign msc
//2 hlr tells vlr about deletion
//-2 vlr tells hlr confirming deletion

//message hlr sends
public class Message implements Serializable
{
	char MSC_ID;
	int status;
	String MSISDN;
	public Message(char MSC_ID,int status,String MSISDN)
	{
		this.MSC_ID=MSC_ID;
		this.status=status;
		this.MSISDN=MSISDN;
	}
}
