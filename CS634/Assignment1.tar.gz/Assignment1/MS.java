import java.io.*;

public class MS implements Serializable
{
	String IMEI;
	SIM sim;
	public MS(String imei,SIM sim)
	{
		this.IMEI=imei;
		this.sim=sim;
	}
}

