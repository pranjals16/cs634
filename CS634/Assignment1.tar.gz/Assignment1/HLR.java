//class HLR defining attributes of HLR
public class HLR
{
	String IMEI;
	String MSISDN;
	String VLR;
	String Subscription_info;
	String Ki;		//referrence to auc for getting ki
	public HLR(String IMEI,String MSISDN,String VLR,String si,String ki)				//constructor for creating instances of hlr
	{
		this.IMEI=IMEI;
		this.MSISDN=MSISDN;
		this.VLR=VLR;
		this.Subscription_info=si;
		this.Ki=ki;
	}
}
