import java.io.*;
import java.net.*;
import java.util.*;

//thread for mobile communication
class socketThread implements Runnable
{
	Socket connectionSocket;
	ObjectInputStream fromClient;
	ObjectOutputStream outServer;
	public socketThread(Socket s,ObjectInputStream fc,ObjectOutputStream os)
	{
		this.connectionSocket=s;
		this.fromClient=fc;
		this.outServer=os;
	}
	public void run() 
	{
		String clientSentence="";
		String capitalSentence="";
		try {
		while(connectionSocket.isConnected()){
        	    clientSentence=(String)fromClient.readObject();
        	    capitalSentence=clientSentence.toUpperCase();
        	    outServer.writeObject(capitalSentence);
 //       	    System.out.println(clientSentence+"\t"+capitalSentence);
		}
		}
		catch(Exception e) { System.out.println("Disconnected");}
	}
}

public class MSC2 extends Thread
{
	static char MSC_ID='2';								//MSC_ID of current MSC
	static char Foreign_MSC[]={'1','3','4','5'};					//MSC IDs of foreign MSCs						
	static int Foreign_MSC_port[]={6790,6794,6796,6798};		//ports of foreign respective MSC
	static ArrayList<HLR> hlrList=new ArrayList<HLR>();		//global HLR list storing hlr of mobile of home msc
	static ArrayList<VLR> vlrList=new ArrayList<VLR>();		//global vlr list stroing vlr of mobile of foreign 

	//function when mobile enters MSC for the first time
	public static int registration(MS ms) throws Exception
	{
		//mobile set of home area registration
		if(ms.sim.IMSI.charAt(0)==MSC_ID)					//IMSI gives the address of home MSC
		{
			for (HLR h : hlrList)							//browsing in hlr list to see if entry already exists
			{
				//mobile enters home msc from foreign msc
				if(h.MSISDN.equals(ms.sim.MSISDN) && h.VLR!="")
				{
					//contact vlr to delete entry
					System.out.println("MS with MSISDN "+ms.sim.MSISDN+" re-enters home from foreign MSC "+h.VLR+"...contacting vlr for deletion ");
					int i;
					for(i=0;i<Foreign_MSC.length;i++)
					    if(Foreign_MSC[i]==h.VLR.charAt(0))
					      break;
					
					//creating socket for vlr deletion and sending msg to vlr
					Socket vlrDeletion=new Socket(InetAddress.getLocalHost().getHostName(),Foreign_MSC_port[i]);
					Message msg=new Message(MSC_ID,2,ms.sim.MSISDN);
					ObjectOutputStream toVLRDeletion=new ObjectOutputStream(vlrDeletion.getOutputStream());
					ObjectInputStream fromHLRDeletion=new ObjectInputStream(vlrDeletion.getInputStream());
					toVLRDeletion.writeObject(msg);
					//receiving the response from vlr
					Message m=(Message)fromHLRDeletion.readObject();
					if(m.status!=-2)
					{
						System.out.println("Deletion unsuccesfull");
						return -1;
					}
					vlrDeletion.close();
					//making vlr field to null
					h.VLR="";
					h.IMEI=ms.IMEI;	//if changes handset
					return 1;
				}
				//already registered in home msc (if restarts mobile)
				else if(h.MSISDN.equals(ms.sim.MSISDN))
				{
					System.out.println("Mobile is registered");
					h.IMEI=ms.IMEI;
					return 1;
				}
			}
			//register for the first time
			System.out.println("Adding MS with MSISDN "+ms.sim.MSISDN+" in HLRList");
			HLR h=new HLR(ms.IMEI,ms.sim.MSISDN,"","",ms.sim.Ki);
			hlrList.add(h);
			System.out.println("Added in HLR");
			return 1;
		}
		//mobile set of visitor area registration
		else
		{
			System.out.println("MS with MSISDN "+ms.sim.MSISDN+" in Foreign MSC");
			//finding the home msc id
			char h_msc_id=ms.sim.IMSI.charAt(0);
			//checking if valid home
			for(int i=0;i<Foreign_MSC.length;i++)
			{
				if(h_msc_id==Foreign_MSC[i])
				{
					//contact home
					System.out.println("Contacting home MSC "+Foreign_MSC[i]);
					//creating socket to contact to home msc
					Socket msc_contact=new Socket(InetAddress.getLocalHost().getHostName(),Foreign_MSC_port[i]);
					ObjectOutputStream toHomeMSC=new ObjectOutputStream(msc_contact.getOutputStream());
					ObjectInputStream fromHomeMSC=new ObjectInputStream(msc_contact.getInputStream());
					Message v=new Message(MSC_ID,1,ms.sim.MSISDN);
					toHomeMSC.writeObject(v);
					Message h=(Message)fromHomeMSC.readObject();
					//msg received from home
					if(h_msc_id==h.MSC_ID)
					{
						//adding in vlr if entry in home hlr exists
						if(h.status==0)
						{
							System.out.println("Adding in VLR");
							VLR vmsg=new VLR(ms.sim.IMSI,ms.sim.MSISDN,Character.toString(h.MSC_ID),"","");
							vlrList.add(vmsg);
							msc_contact.close();
							return 0;
						}
						//not registered in home msc
						else if(h.status==-1)
						{
							System.out.println("Not registered in home MSC\n");
							msc_contact.close();
							return -1;
						}
					};
				}
			}
			System.out.println("Invalid Number");
			return -1;
		}
	}
	
	public static void main(String arg[]) throws Exception
	{
		Thread t1=new Thread(new Runnable() {
		  public void run()
		  {
		    try{
		    //socket for foreign msc to contact
		    ServerSocket fromForeignMSC=new ServerSocket(6792);
		    System.out.println("Socket created for foreign msc to contact");
		    while(true)
		    {
			     Socket s=fromForeignMSC.accept();
			    ObjectInputStream fromVLR=new ObjectInputStream(s.getInputStream());
			    ObjectOutputStream toVLR=new ObjectOutputStream(s.getOutputStream());
			    Message msgFromForeignMSC=(Message)fromVLR.readObject();
			    //check if request for deletion
			    if(msgFromForeignMSC.status==2)
			    {
				    System.out.println("Request for deletion of MS with MSISDN "+msgFromForeignMSC.MSISDN+" in vlr list");
				    for( VLR v : vlrList)
				    {
					    if(v.MSISDN.equals(msgFromForeignMSC.MSISDN))
					    {
						    vlrList.remove(v);
						    System.out.println("Deleted From VLR");
						    break;
					     }
				    }
				    Message msgToHomeMSC=new Message(MSC_ID,-2,msgFromForeignMSC.MSISDN);
				    toVLR.writeObject(msgToHomeMSC);
			    }
			    //else request from vlr to update home msc
			    else
			    {
				    int status=-1;
				    System.out.println("Request from VLR "+msgFromForeignMSC.MSC_ID+" to update hlr");
				    //checking if entry in hlr exists
				    for (HLR h: hlrList)
				    {
					     if(h.MSISDN.equals(msgFromForeignMSC.MSISDN))
					    {
						    status=0;
						    if(!h.VLR.equals("") && h.VLR.charAt(0)!=(msgFromForeignMSC.MSC_ID))
						    {
							    System.out.println("Sending request to MSC "+h.VLR+" for deletion in its VLR list");
							    int i;
								for(i=0;i<Foreign_MSC.length;i++)
					   			 	if(Foreign_MSC[i]==h.VLR.charAt(0))
					     					 break;
							    Socket sck=new Socket(InetAddress.getLocalHost().getHostName(), Foreign_MSC_port[i]);
							    Message m=new Message(MSC_ID,2,h.MSISDN);
							    ObjectOutputStream toVLRForDeletion=new ObjectOutputStream(sck.getOutputStream());
							    ObjectInputStream fromVLRDeletion=new ObjectInputStream(sck.getInputStream());
							    toVLRForDeletion.writeObject(m);
							    Message n=(Message)fromVLRDeletion.readObject();
							    if(n.MSC_ID==h.VLR.charAt(0) && status==-2)
							    {
								    System.out.println("Deletion in VLR successfull");
							    }
							    sck.close();
						    }
						    System.out.println("Updating VLR field in the HLR ");
						    h.VLR=Character.toString(msgFromForeignMSC.MSC_ID);
						    Message msg=new Message(MSC_ID,status,h.MSISDN);
						    toVLR.writeObject(msg);
							s.close();
						    break;
					    }
				    }
				    //if no entry then return error status to vlr
				    if(status==-1)
				    {
					    System.out.println("Not Found in HLR");
					    Message msg=new Message(MSC_ID,status,msgFromForeignMSC.MSISDN);
					    toVLR.writeObject(msg);
				    }
					s.close();
			    }
		    }
		    }
		    catch(Exception e) { e.printStackTrace();}
		}
		});
		Thread t2=new Thread(new Runnable() {
		public void run()
		{
		try{
		//new Serversocket for MS
		ServerSocket server=new ServerSocket(6791);
		System.out.println("Socket Server started on port 6791. Waiting for connection...");
		Thread t=new Thread();
		t.start();
		while(true)
		{
			Socket s=server.accept();
			System.out.println("Connection request recevied");
			ObjectInputStream fromClient=new ObjectInputStream(s.getInputStream());
	        	ObjectOutputStream outServer=new ObjectOutputStream(s.getOutputStream());
			//SIM sim=(SIM)fromClient.readObject();
			//System.out.println(sim.IMSI+" "+sim.MSISDN);
			MS ms=(MS)fromClient.readObject();
			System.out.println("Connection received from MS\nIMSI="+ms.sim.IMSI+" MSISDN= "+ms.sim.MSISDN+" IMEI="+ms.IMEI);
			int id=registration(ms);
			if(id==-1)
				ms.sim.Ki="Invalid";
			outServer.writeObject(ms);
			//System.out.println(id);
			Thread t3=new Thread(new socketThread(s,fromClient,outServer));
			t3.start();
		}
		}
		catch(Exception e){ e.printStackTrace();}
		}});
		t1.start();
		t2.start();
	}
}
