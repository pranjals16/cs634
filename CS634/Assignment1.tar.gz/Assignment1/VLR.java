//class VLR defining attributes of VLR
public class VLR
{
	String IMSI;
	String MSISDN;
	String HLR;
	String AP;	//accessPoint GPRS(subscribed)
	String services;
	public VLR(String IMSI,String MSISDN, String HLR,String AP,String services)		//constructor for creating instances of vlr
	{
		this.IMSI=IMSI;
		this.MSISDN=MSISDN;
		this.HLR=HLR;
		this.AP=AP;
		this.services=services;
	}
}
