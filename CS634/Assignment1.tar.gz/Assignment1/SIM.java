import java.io.*;
public class SIM implements Serializable
{
	String IMSI;
	String MSISDN;
	String PIMSI;
	String Ki;
	String A3;
	String A8;
	String Kc;
	String TIMSI,LAI,RAI;
	String MSRSN;
	
	public SIM(String imsi,String msisdn,String pimsi,String ki,String a3,String a8,String kc,String timsi,String lai,String rai)
	{
		this.IMSI=imsi;
		this.MSISDN=msisdn;
		this.PIMSI=pimsi;
		this.Ki=ki;
		this.A3=a3;
		this.A8=a8;
		this.Kc=kc;
		this.TIMSI=timsi;
		this.LAI=lai;
		this.RAI=rai;
		this.MSRSN="";
	}
}

