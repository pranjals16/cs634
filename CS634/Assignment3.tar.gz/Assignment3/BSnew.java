import java.io.*;
import java.net.*;
import java.util.*;

public class BSnew extends Thread
{
	static String BSC_ID="2";
	static int port_BSC=6793;
	static String BS_ID="2";
	static int port_MS=6788;
	static int port_MSC=6792;
	static int chAv=0;
	static void flush(Message m)
	{
		try {
		Socket fl=new Socket(InetAddress.getLocalHost().getHostName(), port_BSC);
		System.out.println("Flush request to BSC"+m.oldBSC+" BS"+m.oldBS);
		Message newm=new Message(12,m.MSISDN,m.oldBS,m.oldBSC,"","",0);
		ObjectOutputStream out=new ObjectOutputStream(fl.getOutputStream());
		out.writeObject(newm);
		return;
		}
		catch(Exception e){ e.printStackTrace();}
	}
	static ArrayList<String> mobList=new ArrayList<String>();	

	static void create(final int port)
	{
		Thread t=new Thread(new Runnable() {
		//int nport=0;
		
		public void run() {
		try
		{
			System.out.println("Creating port "+port);
			ServerSocket ss=new ServerSocket(port);
			int cport=port;int oport=0;
			Socket s=ss.accept();
			ObjectOutputStream o=new ObjectOutputStream(s.getOutputStream());
			ObjectInputStream i=new ObjectInputStream(s.getInputStream());
			Message ha=(Message)i.readObject();
			if(mobList.contains(ha.MSISDN) && ha.type==10)
			{
				System.out.println("Link request received frm BS"+ha.oldBS+" BSC"+ha.oldBSC);
				Message newm=new Message(11,ha.MSISDN,"","",ha.newBSC,BS_ID,0);
				o.writeObject(newm);
				flush(ha);
			}
			if(mobList.contains(ha.MSISDN) && ha.type==26)
			{
				System.out.println("Link request received frm BS"+ha.oldBS+" BSC"+ha.oldBSC);
				Message newm=new Message(11,ha.MSISDN,"","",ha.newBSC,BS_ID,0);
				o.writeObject(newm);
				//flush(ha);
			}
			for(int j=0;j<100000000;j++);
			//while(nport==0);
			Thread.sleep(20000);
			oport=cport;
			cport=chAv;
			chAv=0;
			ServerSocket newss=new ServerSocket(cport);
			System.out.println("Switch to second avialable borrowed channel "+cport);
			Message mesg=new Message(25,ha.MSISDN,"",ha.oldBSC,BSC_ID,BS_ID,cport);
			o.writeObject(mesg);
			s.close();
			ss.close();
			Socket b=new Socket(InetAddress.getLocalHost().getHostName(),port_BSC);
			ObjectOutputStream out=new ObjectOutputStream(b.getOutputStream());
			Message msg=new Message(23,"","","","","",oport);
			out.writeObject(msg);
			b.close();
			Socket news=newss.accept();
			ObjectOutputStream newo=new ObjectOutputStream(news.getOutputStream());
			ObjectInputStream newi=new ObjectInputStream(news.getInputStream());
			Message a=(Message)newi.readObject();
			if(mobList.contains(a.MSISDN) && a.type==10)
			{
				System.out.println("Link request received frm MS");
				Message newm=new Message(11,a.MSISDN,"","",a.newBSC,BS_ID,0);
				newo.writeObject(newm);
				flush(ha);
			}
			if(mobList.contains(a.MSISDN) && a.type==26)
			{
				System.out.println("Link request received frm MS");
				Message newm=new Message(11,a.MSISDN,"","",a.newBSC,BS_ID,0);
				newo.writeObject(newm);
				//flush(ha);
			}
			
			for(double j=0;j<100000000;j+=0.5);
			System.out.println("Switch(1) or close(2)");
			InputStreamReader r=new InputStreamReader(System.in);
			BufferedReader br=new BufferedReader(r);
			int ch=Integer.parseInt(br.readLine());
			if(ch==1)
			{
				System.out.println("Switching to channel 6795 (local channel)");
				Message ms=new Message(25,ha.MSISDN,"",ha.oldBSC,BSC_ID,BS_ID,6795);
				newo.writeObject(ms);
				news.close();
				newss.close();
				Socket bsc=new Socket(InetAddress.getLocalHost().getHostName(),port_BSC);
				ObjectOutputStream outb=new ObjectOutputStream(bsc.getOutputStream());
				Message nmsg=new Message(23,"","","","","",cport);
				outb.writeObject(nmsg);
				b.close();
			}
			else
			{
				for(int j=0;j<100000000;j++);
				System.out.println("Closing the connection "+cport);
				Message m=new Message(21,"","","","","",0);
				newo.writeObject(m);
				Message newm=(Message)newi.readObject();
				if(newm.type==22)
				{
					news.close();
					newss.close();
					Socket nb=new Socket(InetAddress.getLocalHost().getHostName(),port_BSC);
					ObjectOutputStream nout=new ObjectOutputStream(nb.getOutputStream());
					Message msgn=new Message(23,"","","","","",cport);
					nout.writeObject(msgn);
					b.close();
				}
			}
		}
		catch(Exception e) { e.printStackTrace(); }
		}
		});
		t.start();
	}	

	public static void main(String arg[]) throws Exception
	{
		Thread t2=new Thread(new Runnable() {
		public void run()
		{
			try{
				ServerSocket newTCH=new ServerSocket(6795);
				while(true)
				{
					Socket s=newTCH.accept();
					ObjectOutputStream out=new ObjectOutputStream(s.getOutputStream());
					ObjectInputStream in=new ObjectInputStream(s.getInputStream());
					Message m= (Message)in.readObject();
					if(mobList.contains(m.MSISDN) && m.type==10)
					{
						System.out.println("Link request received frm MS");
						Message newm=new Message(11,m.MSISDN,"","",m.newBSC,BS_ID,0);
						out.writeObject(newm);
						flush(m);
					}
					if(mobList.contains(m.MSISDN) && m.type==26)
					{
						System.out.println("Link request received frm MS");
						Message newm=new Message(11,m.MSISDN,"","",m.newBSC,BS_ID,0);
						out.writeObject(newm);
						//flush(ha);
					}
					else s.close();
					for(int j=0;j<100000000;j++);
					System.out.println("Closing the connection 6795");
					Message mg=new Message(21,"","","","","",0);
					out.writeObject(mg);
					Message newm=(Message)in.readObject();
					if(newm.type==22)
					{
						s.close();
						newTCH.close();
					}
				}
			}
			catch (Exception e) {System.out.println("Disconnected");}
		}
		});t2.start();
		Thread t1=new Thread(new Runnable() {
		public void run()
		{
			try{
				//socket for left to contact
		  		ServerSocket new_bs=new ServerSocket(6794);
				System.out.println("Socket created at 6794");
				while(true)
				{
					Socket s=new_bs.accept();
					int sig[]=new int[6];
					ObjectInputStream in=new ObjectInputStream(s.getInputStream());
					Message m =(Message) in.readObject();
					s.close();
					//change m to newm
					// 4 : from BSCnew to BSnew (4,MSISDN, oldBS no,oldBSC, newBSC, newBS)
					// 5 : from BSnew to BSCnew
					if(m.type==4)
					{
						Message newm=new Message(5,m.MSISDN,m.oldBS,m.oldBSC,m.newBSC,m.newBS,6795);
						Socket sck=new Socket(InetAddress.getLocalHost().getHostName(), port_BSC);
						ObjectOutputStream out=new ObjectOutputStream(sck.getOutputStream());
						out.writeObject(newm);
						System.out.println("Sending ack to new BSC");
						mobList.add(m.MSISDN);
						sck.close();
						//check if request for deletion
					}	
					if(m.type==20)
					{
						mobList.add(m.MSISDN);
						create(m.newChannel);
						Message newm=new Message(5,m.MSISDN,m.oldBS,m.oldBSC,m.newBSC,m.newBS,m.newChannel);
						Socket sck=new Socket(InetAddress.getLocalHost().getHostName(), port_BSC);
						ObjectOutputStream out=new ObjectOutputStream(sck.getOutputStream());
						out.writeObject(newm);
						System.out.println("Sending ack to new BSC about borrowed channel");
						
						sck.close();
					}	
					if(m.type==28)
					{
						//t.chng(m.newChannel);
						chAv=m.newChannel;
						//create(m.newChannel);
					}	   
			    }
				}
		    catch(Exception e) { e.printStackTrace();}
		}
		});t1.start();
	}
}
