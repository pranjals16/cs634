import java.io.*;
import java.net.*;
import java.util.*;

class c1 implements Runnable
{	
	boolean flag;
	ServerSocket freeChannel;
	public c1()
	{
		Thread t=new Thread(this);
		this.flag=true;
		t.start();
	}
	public void run()
	{
		try
		{
			if(flag==true){
			freeChannel=new ServerSocket(6797);
			System.out.println("Sarting connection 6797");}
		}
		catch (Exception e) { e.printStackTrace();}
	}
	synchronized void swap()
	{
		try {
		if (flag==true)
		{
			 flag=false;
			System.out.println("Closing connection");
			freeChannel.close();
		}
		else
		{
			 flag=true;
			freeChannel=new ServerSocket(6797);
			System.out.println("Channel restarted 6797");
		}
		}catch (Exception e){e.printStackTrace();}
	}
}

class c2 implements Runnable
{	
	boolean flag;
	ServerSocket fC;
	public c2()
	{
		Thread t=new Thread(this);
		this.flag=false;
		t.start();
	}
	public void run()
	{
		try
		{
			if(flag==true) {
			fC=new ServerSocket(6798);
			System.out.println("Sarting connection 6798");}
		}
		catch (Exception e) { e.printStackTrace();}
	}
	synchronized void swap()
	{
		try {
		if (flag==true)
		{
			 flag=false;
			System.out.println("Closing connection");
			fC.close();
		}
		else
		{
			 flag=true;
			fC=new ServerSocket(6798);
			System.out.println("Channel restarted 6798");
		}
		}catch (Exception e){e.printStackTrace();}
	}
}

public class DonorBSC
{
	static int port_AcceptorBSC=6793;
	public static void main (String arg[])
	{
		final c1 bChannel = new c1();
		final c2 bChannel2=new c2();
		//c.start();
		Thread th=new Thread(new Runnable()
		{
			public void run()
			{
				try{
				double i=0;
				for(i=0;i<=1000000000;i+=1);
				//c2 bCh=new c2();
				Socket sck=new Socket(InetAddress.getLocalHost().getHostName(),port_AcceptorBSC);
				ObjectOutputStream o=new ObjectOutputStream(sck.getOutputStream());
				Message newm=new Message(27,"","","","","",6798);
				//bChannel.swap();
				o.writeObject(newm);
				System.out.println("Sending second channel 6798 to be available");
				sck.close();
				}
				catch(Exception e){e.printStackTrace();}
			}
		});
		th.start();
		Thread t2=new Thread(new Runnable()
		{
			public void run()
			{
				try 
				{
					double i=0;
					ServerSocket ss= new ServerSocket(6796);
					System.out.println("Creating socket");
					while(true)
					{
						Socket s=ss.accept();
						ObjectInputStream in=new ObjectInputStream(s.getInputStream());
						Message m=(Message)in.readObject();
						System.out.println("Receiveing message");
						s.close();
						/*if(i==1000000000)
						{
							c2 bCh= new c2();
							Socket sck=new Socket(InetAddress.getLocalHost().getHostName(),port_AcceptorBSC);
							ObjectOutputStream o=new ObjectOutputStream(sck.getOutputStream());
							Message newm=new Message(27,m.MSISDN,m.oldBS,m.oldBSC,m.newBSC,m.newBS,6798);
							o.writeObject(newm);
							System.out.println("Sending channel number to Acceptor");
							sck.close();
						}
						i=i+0.5;*/
						if(m.type==18)//CONDITION FOR BORROW
						{
							bChannel.swap();
							Socket sck=new Socket(InetAddress.getLocalHost().getHostName(),port_AcceptorBSC);
							ObjectOutputStream o=new ObjectOutputStream(sck.getOutputStream());
							Message newm=new Message(19,m.MSISDN,m.oldBS,m.oldBSC,m.newBSC,m.newBS,6797);
							o.writeObject(newm);
							System.out.println("Sending channel number 6797 to Acceptor");
							sck.close();
							//lock the port...not to be used for borrow by others	
						}
						else if(m.type==24) //CONDITION FOR RETURN 
						{
							if(m.newChannel==6797)
							bChannel.swap();
							else if(m.newChannel==6798)
							bChannel2.swap();
							System.out.println("Message received to release the borrowed channel "+m.newChannel);
							//release the lock
						}
					}
				}
				catch (Exception e) { e.printStackTrace(); }
			}
		});
		t2.start();
	}
}
