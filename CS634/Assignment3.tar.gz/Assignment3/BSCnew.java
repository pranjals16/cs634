import java.io.*;
import java.net.*;
import java.util.*;

public class BSCnew extends Thread
{
	static int BSC_ID=2;
	static String BS_ID="BS2";
	static int port_MSC=6792;
	static int port_BS=6794;
	static int port_DonorBSC=6796;

	public static void main(String arg[]) throws Exception
	{
		Thread t1=new Thread(new Runnable() {
		public void run()
		{
			try{
				//socket for left to contact
		  		ServerSocket new_bsc=new ServerSocket(6793);
				System.out.println("Socket created at port 6793");
				while(true)
				{
					Socket s=new_bsc.accept();
					ObjectInputStream in=new ObjectInputStream(s.getInputStream());
					Message m =(Message) in.readObject();
					s.close();
					Random rand=new Random();
					int borrow=1;
					if(m.type==3 && borrow==1)
					{
						Message newm=new Message(18,m.MSISDN,m.oldBS,m.oldBSC,m.newBSC,m.newBS,0);
						Socket sck=new Socket(InetAddress.getLocalHost().getHostName(),port_DonorBSC);
						ObjectOutputStream out=new ObjectOutputStream(sck.getOutputStream());
						out.writeObject(newm);
						System.out.println("Sending request to BSC for lending a channel");
						sck.close();
					}
					//change m to newm
					// from MSC to BSCnew (3,MSISDN, oldBS, oldBSC, newBSC, newBS)
					//  from BSCnew to BSnew (4,MSISDN, oldBS no,oldBSC, newBSC, newBS)
					if(m.type==3 && borrow==0)
					{
						Message newm=new Message(4,m.MSISDN,m.oldBS,m.oldBSC,m.newBSC,m.newBS,0);
						Socket sck=new Socket(InetAddress.getLocalHost().getHostName(), port_BS);
						ObjectOutputStream out=new ObjectOutputStream(sck.getOutputStream());
						out.writeObject(newm);
						System.out.println("sending request to new BS");
						sck.close();
						//check if request for deletion
					}		
					// 5 : from BSnew to BSCnew
					// 6 : from BSCnew to MSC
					if(m.type==5)
					{
						Message newm=new Message(6,m.MSISDN,m.oldBS,m.oldBSC,m.newBSC,m.newBS,m.newChannel);
						Socket sck=new Socket(InetAddress.getLocalHost().getHostName(), port_MSC);
						ObjectOutputStream out=new ObjectOutputStream(sck.getOutputStream());
						out.writeObject(newm);
						System.out.println("Sending ack to MSC");
						sck.close();
					}
					if(m.type==12)
					{
						Message newm=new Message(13,m.MSISDN,m.oldBS,m.oldBSC,m.newBSC,m.newBS,m.newChannel);
						Socket sck=new Socket(InetAddress.getLocalHost().getHostName(), port_MSC);
						ObjectOutputStream out=new ObjectOutputStream(sck.getOutputStream());
						out.writeObject(newm);
						System.out.println("Sending flush request to MSC");
						sck.close();
					}
					if(m.type==19)
					{
						Message newm=new Message(20,m.MSISDN,m.oldBS,m.oldBSC,m.newBSC,m.newBS,m.newChannel);
						Socket sck=new Socket(InetAddress.getLocalHost().getHostName(),port_BS);
						ObjectOutputStream out=new ObjectOutputStream(sck.getOutputStream());
						out.writeObject(newm);
						System.out.println("Sending message to BS about borrowed channel");
						sck.close();
					}
					if(m.type==23)
					{
						Message newm=new Message(24,"","","","","",m.newChannel);
						Socket sck=new Socket(InetAddress.getLocalHost().getHostName(),port_DonorBSC);
						ObjectOutputStream out=new ObjectOutputStream(sck.getOutputStream());
						out.writeObject(newm);
						System.out.println("Sending message to Donor BSC to release the borrowed channel");
						sck.close();
					}
					if(m.type==27)
					{
						Message newm=new Message(28,"","","","","",m.newChannel);
						Socket sck=new Socket(InetAddress.getLocalHost().getHostName(),port_BS);
						ObjectOutputStream out=new ObjectOutputStream(sck.getOutputStream());
						out.writeObject(newm);
						System.out.println("Sending message to BS about second borrowed channel available");
						sck.close();
					}
			    }
				}
		    catch(Exception e) { e.printStackTrace();}
		}
		});t1.start();
	}
}
