// 1 : from BS to BSC old(1,MSISDN, oldBS, oldBSC, null, newBS)
// 2 : from BSCold to MSC (2,MSISDN, oldBS, oldBSC, null, newBS)
// 3 : from MSC to BSCnew (3,MSISDN, oldBS, oldBSC, newBSC, newBS)
// 4 : from BSCnew to BSnew (4,MSISDN, oldBS no,oldBSC, newBSC, newBS)
// 5 : from BSnew to BSCnew
// 6 : from BSCnew to MSC
// 7 : from MSC to BSCold
// 8 : from BSCold to BSold

import java.io.*;

public class Message implements Serializable
{
	int type;
	int signal[]={0,0};
	String MSISDN;
	String oldBS;
	String oldBSC;
	String newBSC;
	String newBS;
	int newChannel;
	public Message(int t, String a,String b,String c,String d, String e,int ch,int[] s)
	{
		this.type=t;
		this.MSISDN=a;
		this.oldBS=b;
		this.oldBSC=c;
		this.newBSC=d;
		this.newBS=e;
		this.newChannel=ch;
		if(t==1 || t==0)
			for(int i=0;i<2;i++)
				this.signal[i]=s[i];
	}
	public Message(int t, String a,String b,String c,String d, String e,int ch)
	{
		this.type=t;
		this.MSISDN=a;
		this.oldBS=b;
		this.oldBSC=c;
		this.newBSC=d;
		this.newBS=e;
		this.newChannel=ch;
		
	}
}
