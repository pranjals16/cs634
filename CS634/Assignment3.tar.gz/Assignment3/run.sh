#! /bin/bash
javac *.java
