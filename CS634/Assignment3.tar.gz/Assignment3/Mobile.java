import java.io.*;
import java.util.*;
import java.net.*;
class ScheduledTask extends TimerTask {
 	String MSISDN;
	String BS;
	int BS_port;
	public ScheduledTask(String a,String b,int c)
	{
		this.MSISDN=a;
		this.BS=b;
		this.BS_port=c;
	}
	public void run() {
		Random rand=new Random();
		int sig[]=new int[2];
		for(int i=0;i<2;i++)
			sig[i]=rand.nextInt(10)+1;
		try{
		
		Socket clientSocket=new Socket(InetAddress.getLocalHost().getHostName(),BS_port);	
		ObjectOutputStream toBS=new ObjectOutputStream(clientSocket.getOutputStream());System.out.println("Gathering signals");
		Message m=new Message(0,MSISDN,BS,"","","",0,sig);
		System.out.println("Sending request. Signal levels="+sig[0]+" and "+sig[1]);
		toBS.writeObject(m);
		clientSocket.close();
		}
		catch(Exception e){e.printStackTrace();}
	}
}

public class Mobile extends Thread
{
	static int port_BS=6790;
	static String BS_ID="1";
	static void connect(Message n,int turn)
	{
		try {
		System.out.println("Connecting to "+n.newChannel);
		Socket s=new Socket(InetAddress.getLocalHost().getHostName(),n.newChannel);
		ObjectOutputStream toBS=new ObjectOutputStream(s.getOutputStream());
		ObjectInputStream fromBS=new ObjectInputStream(s.getInputStream());
		Message m;
		if(turn==0)
		m=new Message(10,n.MSISDN,n.oldBS,n.oldBSC,n.newBSC,n.newBS,0); 
		else
		m=new Message(26,n.MSISDN,n.oldBS,n.oldBSC,n.newBSC,n.newBS,0); 
		toBS.writeObject(m);
		Message newm=(Message)fromBS.readObject();
		if(newm.type==11)
		{
			System.out.println("Handoff complete. New BS="+n.newChannel);
		}
		while(true)
		{
			Message msg=(Message)fromBS.readObject();
			if(msg.type==21)	
			{
				Message nm=new Message(22,"","","","","",0);
				toBS.writeObject(nm);
				s.close();
				break;
			}
			if(msg.type==25)
			{
				s.close();
				connect(msg,1);
				break;
			}
		}
		}
		catch (Exception e) {e.printStackTrace();}
	}
	public static void main(String arg[]) throws Exception
	{
		String sentence;
		String serverSentence;
		int SACCH=6790;
		BufferedReader fromUser=new BufferedReader(new InputStreamReader(System.in));
		System.out.print("MSISDN:");
		String MSISDN=fromUser.readLine();
		System.out.println("Connected to BS  "+BS_ID);
		ScheduledTask st=new ScheduledTask(MSISDN,BS_ID,SACCH);
		final Timer t=new Timer(true);
		t.schedule(st,0,2000);
		Thread t1=new Thread(new Runnable() {
		public void run ()
		{
			try{
			ServerSocket s=new ServerSocket(6788);
			while(true)
			{			
				Socket sck=s.accept();
				ObjectOutputStream o=new ObjectOutputStream(sck.getOutputStream());
				ObjectInputStream i=new ObjectInputStream(sck.getInputStream());
				Message n=(Message)i.readObject();
				sck.close();
				if(n.newChannel!=0 && n.type==9)
				{
					System.out.println("Handoff ack received");t.cancel();
					port_BS=n.newChannel;
					connect(n,0);
				}
				
			}
			}
			catch(Exception e){e.printStackTrace();}
		}
		});
		t1.start();				
	}
}	
