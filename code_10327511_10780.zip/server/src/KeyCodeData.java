class KeyCodeData {
	public String name;
	public boolean modshifted;
	public int localcode;
	public int modifiedcode;
	public boolean shifted;
	public int shiftedcode;
}