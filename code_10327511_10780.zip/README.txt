This folder contains two subfolders namely ->
	>> server
	>> wireless

>> 'server' is a java project developed in eclipse(ADT). To run this project just import this directory in a new project and then run the class file 'MyGestureServer' to start the server.

>> 'wireless' is an android project developed on the same platform. To run the application just import the project as a new android application and run the class file 'MyGesture' to start the main activity.