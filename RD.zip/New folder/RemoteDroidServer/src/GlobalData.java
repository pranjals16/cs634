

public class GlobalData {
	public static AppFrame oFrame;
	public static String basePath;
}