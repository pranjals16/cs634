package com.joshsera;

import android.os.*;

public class SoftResultReceiver extends ResultReceiver {
	//
	//private SoftListener list;
	
	public SoftResultReceiver(Handler handler) {
		super(handler);
	}
}
